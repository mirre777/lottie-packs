fintech-ui — Animation Pack
========================================

Included (Lottie JSON + SVG snapshot + MP4 preview):
1. 01-currency-spinner
2. 02-success-check
3. 03-transfer-coin
4. 04-security-shield
5. 05-bar-chart-growth

Generated for resale on LottieFiles, Gumroad, Motion Array.
