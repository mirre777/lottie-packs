glass-social-loaders — Animation Pack
========================================

Included (Lottie JSON + SVG snapshot + MP4 preview):
1. 01-fb-glass-loader
2. 02-ig-glass-loader
3. 03-yt-glass-loader
4. 04-tw-glass-loader
5. 05-tk-glass-loader

Generated for resale on LottieFiles, Gumroad, Motion Array.
