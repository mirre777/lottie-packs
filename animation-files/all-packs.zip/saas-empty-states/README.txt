saas-empty-states — Animation Pack
========================================

Included (Lottie JSON + SVG snapshot + MP4 preview):
1. 01-empty-inbox
2. 02-no-results
3. 03-upload-cloud
4. 04-no-notifications
5. 05-error-state

Generated for resale on LottieFiles, Gumroad, Motion Array.
