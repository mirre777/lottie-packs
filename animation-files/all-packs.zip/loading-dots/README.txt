loading-dots — Animation Pack
========================================

Included (Lottie JSON + SVG snapshot + MP4 preview):
1. 01-bounce-dots
2. 02-wave-dots
3. 03-pulse-dots
4. 04-elastic-dots
5. 05-fade-dots

Generated for resale on LottieFiles, Gumroad, Motion Array.
